<template>
  <div>
    <h2>{{ pageName }}</h2>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageName: 'Demo'
    }
  }
}
</script>