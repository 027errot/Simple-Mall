<template>
  <div>
    <h2>{{ pageName }}</h2>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageName: '管理员账户管理'
    }
  }
}
</script>