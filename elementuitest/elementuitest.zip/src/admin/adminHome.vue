<template>
  <div>
    <h2>{{ pageName }}</h2>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageName: '管理员页面'
    };
  }
}
</script>